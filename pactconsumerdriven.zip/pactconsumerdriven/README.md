# Chapter 1 - Consumer Test

Consumer Driven Contract Testing with pact-js

## Running the tests

1. `npm install`
2. `npm run pacts` - Run consumer tests
